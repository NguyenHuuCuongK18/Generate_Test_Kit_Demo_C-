﻿public class BookDto
{
    public int BookId { get; set; }
    public string Title { get; set; }
    public string GenreName { get; set; }
}
