﻿using Microsoft.Extensions.Configuration;
using System;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Text.Json;
using System.Xml.Serialization;
public class Product
{
    public int Id { get; set; }
    public string Name { get; set; }
    public int Price { get; set; }
}
class Program
{
    static void Main()
    {
        try
        {
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .Build();

            var ipAddress = config["IpAddress"];
            var port = config["Port"];
            int portParse = port != null ? int.Parse(port) : 0;

            using TcpClient client = new TcpClient();
            client.Connect(ipAddress, portParse);
            NetworkStream stream = client.GetStream();

            // Nhận thông báo kết nối thành công
            byte[] welcomeBuffer = new byte[1024];
            int welcomeBytes = stream.Read(welcomeBuffer, 0, welcomeBuffer.Length);
            string welcomeMsg = Encoding.UTF8.GetString(welcomeBuffer, 0, welcomeBytes);
            Console.WriteLine("[Server] " + welcomeMsg);

            while (true)
            {
                Console.Write("Nhap ProductId de truy van (Enter de thoat): ");
                string input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Vui long nhap ProductId (khong duoc de trong)");
                    continue;
                }

                if (!int.TryParse(input, out int productId))
                {
                    Console.WriteLine("ProductId phai la 1 so nguyen hop le");
                    continue;
                }

                // Gửi request lên server
                byte[] data = Encoding.UTF8.GetBytes(input);
                stream.Write(data, 0, data.Length);

                // Đọc response JSON từ server
                byte[] buffer = new byte[1024];
                int bytesRead = stream.Read(buffer, 0, buffer.Length);
                //string response = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                //Console.WriteLine("Raw JSON từ server: " + response);

                //// Deserialize JSON -> object
                //var product = JsonSerializer.Deserialize<Product>(response);
                //Console.WriteLine($"ID: {product.Id}, Name: {product.Name}, Price: {product.Price}");

                // deserialize BinaryReader
                //byte[] buffer = new byte[4096];
                //int bytesRead = stream.Read(buffer, 0, buffer.Length);

                //using var ms = new MemoryStream(buffer, 0, bytesRead);
                //using var reader = new BinaryReader(ms);

                //bool hasProduct = reader.ReadBoolean();
                //if (hasProduct)
                //{
                //    int id = reader.ReadInt32();
                //    string name = reader.ReadString();
                //    int price = reader.ReadInt32();

                //    var product = new Product { Id = id, Name = name, Price = price };
                //    Console.WriteLine($"ID: {product.Id}, Name: {product.Name}, Price: {product.Price}");
                //}
                //else
                //{
                //    string message = reader.ReadString();
                //    Console.WriteLine(message);
                //}

                // binaryFormat
                //byte[] buffer = new byte[4096];
                //int bytesRead = stream.Read(buffer, 0, buffer.Length);

                //using var ms = new MemoryStream(buffer, 0, bytesRead);
                //var formatter = new BinaryFormatter();
                //object responseObj = formatter.Deserialize(ms);

                //if (responseObj is Product p)
                //{
                //    Console.WriteLine($"ID: {p.Id}, Name: {p.Name}, Price: {p.Price}");
                //}
                //else
                //{
                //    Console.WriteLine(responseObj.ToString());
                //}

                // parse du lieu ve xml

                string xml = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                //Console.WriteLine("Client received XML:");
                //Console.WriteLine(xml);
                Product? product = null;
                var serializer = new XmlSerializer(typeof(Product));
                using (var sr = new StringReader(xml))
                {
                    product = (Product?)serializer.Deserialize(sr);
                }

                if (product != null)
                {
                    Console.WriteLine($"Id: {product.Id}, Name: {product.Name}, Price: {product.Price}");
                }
                else
                {
                    Console.WriteLine("Không nhận được sản phẩm.");
                }
            }

            Console.WriteLine("Client dong ket noi.");
        }
        catch (Exception ex)
        {
            Console.WriteLine("[ERROR] Khong the ket noi voi server: " + ex.Message);
        }

    }
}
