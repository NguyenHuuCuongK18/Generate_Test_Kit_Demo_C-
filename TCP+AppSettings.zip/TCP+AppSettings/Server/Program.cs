﻿using Microsoft.Extensions.Configuration;
using Server;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Xml.Serialization;
class Program
{
    static void Main()
    {
        // Seed dữ liệu memory
        var categories = new List<Category>
        {
            new Category { Id = 1, Name = "Phone" },
            new Category { Id = 2, Name = "Laptop" }
        };

        var products = new List<Product>
        {
            new Product { Id = 1, Name = "iPhone 14", Price = 29990000, Category = categories[0] },
            new Product { Id = 2, Name = "Samsung Galaxy S23", Price = 24990000, Category = categories[0] },
            new Product { Id = 3, Name = "MacBook Pro 16", Price = 57990000, Category = categories[1] },
            new Product { Id = 4, Name = "Dell XPS 15", Price = 41990000, Category = categories[1] }
        };

        var config = new ConfigurationBuilder().AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .Build();

        var ipAddress = config["IpAddress"];
        var port = config["Port"];
        int portParse = port != null ? int.Parse(port) : 0;
        TcpListener server = new TcpListener(IPAddress.Parse(ipAddress), portParse);
        server.Start();
        Console.WriteLine("Server dang chay...");

        while (true)
        {
            try
            {
                TcpClient client = server.AcceptTcpClient();
                Console.WriteLine("Client da ket noi");

                NetworkStream stream = client.GetStream();

                // Gửi thông báo kết nối thành công
                string welcomeMsg = "Ket noi thanh cong voi server";
                byte[] welcomeData = Encoding.UTF8.GetBytes(welcomeMsg);
                stream.Write(welcomeData, 0, welcomeData.Length);

                // Vòng lặp xử lý nhiều request từ cùng một client
                while (true)
                {
                    byte[] buffer = new byte[1024];
                    int bytesRead = stream.Read(buffer, 0, buffer.Length);

                    // Nếu client ngắt kết nối -> thoát vòng lặp
                    if (bytesRead == 0)
                    {
                        Console.WriteLine("Client da dong ket noi");
                        break;
                    }

                    string received = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                    Console.WriteLine($"Nhan tu client: {received}");

                    if (int.TryParse(received, out int productId))
                    {
                        var product = products.Find(p => p.Id == productId);
                        //var category = categories.Find(cate => cate == product.Category);
                        //product.Category = category;
                        //Console.WriteLine(product);
                        //string response = product != null ? JsonSerializer.Serialize(product) : "Khong tim thay san pham";
                        //byte[] responseData = Encoding.UTF8.GetBytes(response);
                        //stream.Write(responseData, 0, responseData.Length);

                        // BinaryWriter
                        //using var ms = new MemoryStream();
                        //using var writer = new BinaryWriter(ms);

                        //if (product != null)
                        //{
                        //    writer.Write(true); // flag: có sản phẩm
                        //    writer.Write(product.Id);
                        //    writer.Write(product.Name);
                        //    writer.Write(product.Price);
                        //}
                        //else
                        //{
                        //    writer.Write(false); // flag: không tìm thấy
                        //    writer.Write("Khong tim thay san pham");
                        //}

                        //byte[] responseData = ms.ToArray();
                        //stream.Write(responseData, 0, responseData.Length);

                        //using var ms = new MemoryStream();
                        //var formatter = new BinaryFormatter();

                        //// Serialize object hoặc null
                        //formatter.Serialize(ms, product);

                        //byte[] responseData = ms.ToArray();
                        //stream.Write(responseData, 0, responseData.Length);

                        //string filePath = "objectByte.bin";
                        //File.WriteAllBytes(filePath, responseData);

                        // parse du lieu ve xml

                        var serializer = new XmlSerializer(typeof(Product));
                        string xml;
                        using (var sw = new StringWriter())
                        {
                            serializer.Serialize(sw, product);
                            xml = sw.ToString();
                        }
                        byte[] data = Encoding.UTF8.GetBytes(xml);
                        stream.Write(data, 0, data.Length);

                        //Console.WriteLine("Server sent XML:");
                        //Console.WriteLine(xml);

                    }
                    else
                    {
                        byte[] responseData = Encoding.UTF8.GetBytes("Du lieu khong hop le");
                        stream.Write(responseData, 0, responseData.Length);
                    }
                }

                // Đóng kết nối khi client ngắt
                client.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Loi server: " + ex.Message);
            }
        }
    }
}
