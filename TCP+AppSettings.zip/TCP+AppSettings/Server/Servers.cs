﻿using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Server
{
    public class Servers
    {
        private int port;

        public Servers(int port)
        {
            this.port = port;
        }

        public void Start()
        {
            TcpListener server = new TcpListener(IPAddress.Parse("192.168.1.10"), port);
            server.Start();
            Console.WriteLine("Server đang chạy...");

            while (true)
            {
                TcpClient client = server.AcceptTcpClient();
                NetworkStream stream = client.GetStream();
                byte[] buffer = new byte[1024];
                int bytesRead = stream.Read(buffer, 0, buffer.Length);
                string received = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                Console.WriteLine($"Nhận: {received}");

                byte[] response = Encoding.UTF8.GetBytes("Server đã nhận");
                stream.Write(response, 0, response.Length);
                client.Close();
            }
        }
    }
}
