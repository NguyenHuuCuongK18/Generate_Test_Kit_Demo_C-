﻿namespace Server
{
    [Serializable]
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public Category Category { get; set; }

        public override string ToString()
        {
            return $"Product Id: {Id}, Name: {Name}, Price: {Price:C}, Category: {Category.Name}";
        }
    }
}
